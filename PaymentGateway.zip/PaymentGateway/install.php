<?php

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

	global $wpdb;

	$charset_collate = $wpdb->get_charset_collate();
	// Transaction table to be inserted for first charge, plan detail and subscription information
	$table_name = $wpdb->prefix . "stripe_payment_details";
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  time timestamp,
	  email varchar(50) NOT NULL,
	  customer_id varchar(50),
	  UNIQUE KEY id (id)
	) $charset_collate;";
	  
	dbDelta( $sql );
?>
