<?php

require dirname(__FILE__).'/PHPMailer-master/PHPMailerAutoload.php';
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );

class PGMainModel{

	function __construct(){
	}
	function ExecuteStripeProcess( $data ){
		
		// Create Customer
		$customer_id = 	$this->createNewCustomer( $data );
		
		//Charge Customer
		$err_response = $this->createCharge( $customer_id, $data['amount'] );

		
		//Insert customer details into db
		$this->insert_data( $data, $customer_id );
		
		//Mail this to customer
		$this->MailNotification( $data, $err_response );

		if( isset($err_response->error->type) ){
			return 'FAILED';
		}else{
			return 'SUCCESS';
		}
	}

	function createNewCustomer($xdata){

		$md_set = get_option('stripe_mode');
		if( $md_set == 'live' ){
			$stripe_sk_key = get_option('live_sk');
		}elseif( $md_set == 'test' ){
			$stripe_sk_key = get_option('test_sk');
		}else{
			$stripe_sk_key = null;
		}

		$strcurl = curl_init();
		curl_setopt($strcurl, CURLOPT_CAINFO, dirname(__FILE__).'/cacert.pem');
		curl_setopt($strcurl, CURLOPT_SSL_VERIFYPEER, true);
		curl_setopt($strcurl, CURLOPT_USERPWD, $stripe_sk_key );
		curl_setopt_array($strcurl, array(
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => "https://api.stripe.com/v1/customers",
		CURLOPT_USERAGENT => 'cURL Request for creating stripe charge',
		CURLOPT_POST => 1
	  ));


	  	$description = "Payment done from John Doe Store";
	  	$data = "email=".$xdata['email']."&description=".$description."&source=".$xdata['token'];
	  	curl_setopt($strcurl, CURLOPT_POSTFIELDS, $data);
	  	$response = curl_exec($strcurl);
	  	curl_close($strcurl);
		$object = json_decode($response);
		
	  
	  	/*	For reviewing error
			
			print_r(json_encode($object));
	  		print_r(json_encode($errmsg)); 
	    	print_r(json_encode($cInfo)); 
	    	print_r(json_encode(htmlentities($response))); 
		*/
		
		return $object->id;
	}

	function createCharge( $stripe_account_id, $xamount ){
		
		$md_set = get_option('stripe_mode');
		if( $md_set == 'live' ){
			$stripe_sk_key = get_option('live_sk');
		}elseif( $md_set == 'test' ){
			$stripe_sk_key = get_option('test_sk');
		}else{
			$stripe_sk_key = null;
		}
		
		$strcurl = curl_init();
	 	curl_setopt($strcurl, CURLOPT_CAINFO, dirname(__FILE__).'/cacert.pem');
	  	curl_setopt($strcurl, CURLOPT_SSL_VERIFYPEER, true);
	  	curl_setopt($strcurl, CURLOPT_USERPWD, $stripe_sk_key );
	  	curl_setopt_array($strcurl, array(
	  	CURLOPT_RETURNTRANSFER => 1,
	  	CURLOPT_URL => "https://api.stripe.com/v1/charges",
	  	CURLOPT_USERAGENT => 'cURL Request for creating stripe charge',
	  	CURLOPT_POST => 1
	   ));
  		$data_amount = $xamount*100;
		$data = "amount=".$data_amount."&currency=USD&customer=".$stripe_account_id;

		curl_setopt($strcurl, CURLOPT_POSTFIELDS, $data);
		$response = curl_exec($strcurl);
		$object = json_decode($response);
		
	  	
	  	/*	For reviewing error
			
			print_r(json_encode($object));
	  		print_r(json_encode($errmsg)); 
	    	print_r(json_encode($cInfo)); 
	    	print_r(json_encode(htmlentities($response))); 
	    */
		
		
		if( isset($object->error->type) ){
			return $object;
		}else{
			return $object;	
		}
		curl_close($strcurl);
	}

	function insert_data( $data, $customer_id ){
	  	
	  	global $wpdb;
		$table_name = $wpdb->prefix . "stripe_payment_details";
		$sql =  $wpdb->insert($table_name, array(
	           "time" => current_time( "mysql" ),
	           "email" => $data['email'],
	           "customer_id" => $customer_id
	       ));
		if( false === $wpdb->query($sql) ){
	      $wpdb->print_error();
	    }
	}

	function MailNotification( $data, $xerr_response){

		$mail = new PHPMailer;
		/*	SMTP configuration Below
			In order to sent email from your google account please allow access to less secure app from this url
			_>https://www.google.com/settings/security/lesssecureapps
				
			$mail->isSMTP();
			$mail->Debugoutput = 'html';
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 465;
			$mail->SMTPSecure = 'ssl';
			$mail->SMTPOptions = array(
			    'ssl' => array(
			        'verify_peer' => false,
			        'verify_peer_name' => false,
			        'allow_self_signed' => true
			    )
			);
			$mail->SMTPAuth = true;
			$mail->Username = "Gmail Id here";
			$mail->Password = "Gmail password here";
		*/
		$mail->setFrom('johndoe@mail.com', 'John Doe');
		$mail->addAddress($data['email'], $data['fname'].' '.$data['fname']);     // Add a recipient
		//$mail->addAddress('ellen@example.com');    // Name is optional
		$mail->addReplyTo('johndoe@mail.com', 'johndoe@mail.com');
		//$mail->addCC('cc@example.com');
		//$mail->addBCC('bcc@example.com');
		$mail->isHTML(true);  // Set email format to HTML
		if( isset($xerr_response->error->type) ){
			$status = "<li>Payment status: 
							<ul>
								<li>Error type: ".$xerr_response->error->type."</li>
								<li>Error message: ".$xerr_response->error->message."</li>
								<li>Error code: ".$xerr_response->error->code."</li>
								<li>It seems your payment has Failed, Please try again after some time<br>If problem persist contact support (Please not that you have not been charge anything in case the payment is failed )</li>
							</ul>
						</li>";

		}else{
			$status = "<li>Payment status: ".$xerr_response->status."</li>";
		}
		$message = "<html>
			<style type='text/css'>	.mail_ul li{ padding: 5px; margin-left: 9px; font-size: 15px; font-family: ubuntu; }
			.mail_ul{ padding:none; } </style>
						<p>Below are the details of your payment</p>
						<ul class='mail_ul'>
							<li>Email-id: ".$data['email']."</li>
							<li>Total pay: $".$data['amount']."</li>".$status."
						</ul>
					</html>";
		$mail->Subject = 'Payment made on John Doe Store payment status';
		$mail->Body    = $message;
		$mail->AltBody = 'Payment made on John Doe Store payment status';
		
		$mail->send();
	}
}

?>