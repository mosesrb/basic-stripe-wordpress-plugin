<?php
/**
 * Plugin Name: PaymentGateway
 * Description: Plugin for stripe payment gateway
 * Version: 1.0
 * Author: Moses Bharshankar
 */ 

/* Necessary activation below*/
define( 'PG_PLUGIN_PATH', dirname(__FILE__) );
define( 'PG_PLUGIN_MODEL', dirname(__FILE__).'/model' );
define( 'PG_PLUGIN_CONTROL', dirname(__FILE__).'/controller' );

register_activation_hook( __FILE__, 'pg_activate_tables');

function pg_activate_tables(){
	include PG_PLUGIN_PATH . '/install.php';
}
class PGMain{
	
	function __construct(){
		//Get Necessary JS files
		add_action('admin_print_styles', array( $this, 'pg_custom_styles' ));

		add_action( 'admin_enqueue_scripts', array( $this, 'pg_custom_scripts' ) );
		
		add_action( 'admin_menu', array( $this, 'set_menus' ), 10, 2 );

		add_shortcode("StripPaymentGateway", array( $this, 'stripe_payment_gateway' ) );
	}

	function pg_custom_styles() {
		wp_enqueue_style('cl-chanimal-styles', plugin_dir_url( __FILE__ ) . 'css/pg_style.css' );
	}

	function pg_custom_scripts() {
	    wp_enqueue_script( 'main-jquery', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js', array( 'jquery' ) );
	}

	function set_menus(){
	  $roles = new WP_Roles();
	  $roles->add_cap('administrator','can_open_menu',TRUE);
	  add_menu_page('Stripe Payment Settings','StripePayment Settings','can_open_menu','stripe_setting',array(&$this, 'stripeSetting'));
	}

	function stripeSetting(){ 

		//$user_id = get_current_user_id();
		if(!empty($_POST['submit'])){
			if( isset( $_GET['action'] ) and $_GET['action'] == 'set_keys' ){ 

				update_option( 'live_pk', $_POST['live_pk'] );
		 		update_option( 'live_sk', $_POST['live_sk'] );
				update_option( 'test_pk', $_POST['test_pk'] );
				update_option( 'test_sk', $_POST['test_sk'] );
				update_option( 'stripe_mode', $_POST['stripe_mode'] );

				echo "Stripe keys successfully updated";
			 } 
		}	 

		$felv_pk = get_option('live_pk');
		$felv_sk = get_option('live_sk');
		$fets_pk = get_option('test_pk');
		$fets_sk = get_option('test_sk');
		$md_set = get_option('stripe_mode');
		

		if( $felv_pk || $felv_pk != null){
			$live_pk = $felv_pk; 
		}else{
			$live_pk = null;
		}

		if( $felv_sk || $felv_sk != null){
			$live_sk = $felv_sk; 
		}else{
			$live_sk = null;
		}

		if( $fets_pk || $fets_pk != null){
			$test_pk = $fets_pk; 
		}else{
			$test_pk = null;
		}

		if( $fets_sk || $fets_sk != null){
			$test_sk = $fets_sk; 
		}else{
			$test_sk = null;
		}

		if( $md_set || $md_set != null){
			$mode_set = $md_set; 
		}else{
			$mode_set = null;
		}?>
		
		<form method="post" action="admin.php?page=stripe_setting&action=set_keys">
			<ul class="payment_ul">
				<li>
					<lable>Live PK_KEY:</lable>
						<input type="text" name="live_pk" value="<?php echo $live_pk; ?>">
				</li>
				<li>		
					<lable>Live SK_KEY:</lable>
					<input type="text" name="live_sk" value="<?php echo $live_sk; ?>"> 
				</li>
				<li>	
					<lable>Test PK_KEY:</lable>
					<input type="text" name="test_pk" value="<?php echo $test_pk; ?>">
				</li>
				<li>	
					<lable>Test SK_KEY:</lable>
					<input type="text" name="test_sk" value="<?php echo $test_sk; ?>"> 
				</li>
				<li>

					<lable>Please specify mode:</lable>
					<div class="radio_section">
						<span class="radio_spn">Live: </span>
						<span class="radio_box">
							<input type="radio" name="stripe_mode" value="live" <?php if( $mode_set == 'live' ){ echo "checked='checked'"; } ?> >
						</span>	
						<span class="radio_spn"> Test: </span> 
						<span class="radio_box">
							<input type="radio" name="stripe_mode" value="test" <?php if( $mode_set == 'test' ){ echo "checked='checked'"; } ?>>
						</span>	
					</div>	
				</li>
				<li>
					<div class="payment_sub"> 
						<input type="submit" name="submit" value="submit">
					</div>	
				</li>	
			</ul>	
		</form><?php
	}

	function stripe_payment_gateway(){ 

		$md_set = get_option('stripe_mode');
		if( $md_set == 'live' ){
			$stripe_pk_key = get_option('live_pk');
		}elseif( $md_set == 'test' ){
			$stripe_pk_key = get_option('test_pk');
		}else{
			$stripe_pk_key = null;
		} ?>
	   
	    <script src="https://checkout.stripe.com/checkout.js"></script>
	    <script type="text/javascript">
	      	
	       var xsp = jQuery.noConflict();
		   
		   xsp("document").ready(function(){
		   		xsp(".gif_spinner").hide();
		   });
	        var handler = StripeCheckout.configure({
	        	key:"<?php echo $stripe_pk_key; ?>",
		        locale: "auto",
		        token: function(token) {
	                execute_charge(token.id,token.email,97);
		        }
	     	});

	  	 	function valcheck(){

		   	 var amount = 97;
		        handler.open({
		          name: "John Doe Store",
		          description: "Payment amount is $"+makeitincurrency(amount),
		          image:"<?php echo get_site_url(); ?>/wp-content/plugins/PaymentGateway/images/johndoe.png",
		          amount: amount*100,
		          panelLabel:" ",
		          currency: "USD",
		          //bitcoin:"true",
		          locale:"auto"
	       		});
		        //e.preventDefault();
		    }
	     	
	     	// Close Checkout on page navigation
	     	xsp(window).on("popstate", function() {
	        	handler.close();
	      	});
	      	
	      	function execute_charge(tid,temail,amount){

	      		var calculated_amount = amount;

	      		var data = "action=getgoing&email="+temail+"&token="+tid+"&amount="+calculated_amount;
	      		
				xsp('.gif_spinner').show();
	      		xsp.ajax({
	      			type:'post',
	      			data: data,
	      			url: "<?php echo get_site_url();?>/wp-content/plugins/PaymentGateway/controller/PaymentGatewayController.php",
	      			success: function(resultset){
	      				
	      				if( resultset.trim() == 'SUCCESS'){
	      					alert("Thank you, your payment has been processed successfully, check your mail for further instructions");
	      					//window.location.href='<?php echo site_url(); ?>';
	      					window.location.reload;
	      				}else{
	      					alert("Oops!, it seems your payment was unsuccesfull, please check your mail for more info");
	      				}
	      				//window.location.href="/stripe-payment/";
	      				xsp('.gif_spinner').hide();
	      			}
	      		});
	      	}
			
			function makeitincurrency(xtemp){
				xtemp = (parseFloat(xtemp)).toFixed(2);
				var breakit = ""+xtemp;
				var pile = breakit.split(".");
				var brick1 = parseInt(pile[0]).toLocaleString();
				var brick2 = pile[1];
				return brick1+"."+brick2;
			}
	 	</script>
	 	<div><img class="gif_spinner" src="<?php echo get_site_url(); ?>/wp-content/plugins/PaymentGateway/images/spinner.gif"></div>
	 	<div class="mdivbt">
			<div class="subbt">
				<input type="submit" name="paybtn" id="paybtn" value="Paynow" onclick="valcheck()">
			</div>
		</div><?php 
	}

	function get_home_path() {
	    $home    = set_url_scheme( get_option( 'home' ), 'http' );
	    $siteurl = set_url_scheme( get_option( 'siteurl' ), 'http' );
	    if ( ! empty( $home ) && 0 !== strcasecmp( $home, $siteurl ) ) {
	        $wp_path_rel_to_home = str_ireplace( $home, '', $siteurl ); /* $siteurl - $home */
	        $pos = strripos( str_replace( '\\', '/', $_SERVER['SCRIPT_FILENAME'] ), trailingslashit( $wp_path_rel_to_home ) );
	        $home_path = substr( $_SERVER['SCRIPT_FILENAME'], 0, $pos );
	        $home_path = trailingslashit( $home_path );
	    } else {
	        $home_path = ABSPATH;
	    }
	 
	    return str_replace( '\\', '/', $home_path );
	}
}

$obj_main = new PGMain();
define( 'ROOT_DIR_PATH', $obj_main->get_home_path() );

?>