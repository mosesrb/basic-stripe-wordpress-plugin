<?php
include realpath(dirname(__FILE__). '/../model/PaymentGatewayModel.php');
class PGMainController extends PGMainModel{
	function __construct(){
		$data = array();
		if( isset($_POST['action']) and $_POST['action'] == 'getgoing' ){
			
			$data = array(
				"email"=>$_POST['email'],
				"amount"=>$_POST['amount'],
				"token"=>$_POST['token']
			);

			$response = $this->ExecuteStripeProcess($data);
			echo $response;
		}
	}
}

$objcontrol = new PGMainController();
?>

